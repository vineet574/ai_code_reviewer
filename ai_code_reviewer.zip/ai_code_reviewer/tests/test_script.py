# test_script.py
def example_function():
    print('Hello, world!')  # improper spacing
    a = 10
    if a > 5:
        print("A is greater than 5")  # improper indentation and spacing
